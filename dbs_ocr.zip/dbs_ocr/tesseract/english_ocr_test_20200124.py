import pytesseract
import cv2
import os

datafolder = "F:\\MyData\\Photo\\ocr\\test"
datafolder = "D:\\Git\\cnn\\dbc_ocr\\data"
# datapath = os.path.join(datafolder,"IMG_20200312_110433.jpg")
datapath = os.path.join(datafolder,"test.jpg")

# datafolder = "/home/hduser/testing"
# datapath = os.path.join(datafolder,"eurotext.png")
img_cv = cv2.imread(datapath)


# pytesseract.pytesseract.tesseract_cmd = r'C:\Users\USER\AppData\Local\Tesseract-OCR\tesseract.exe'

pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'

# By default OpenCV stores images in BGR format and since pytesseract assumes RGB format,
# we need to convert from BGR to RGB format/mode:
img_rgb = cv2.cvtColor(img_cv, cv2.COLOR_BGR2RGB)
# print(pytesseract.image_to_string(img_rgb))

# tessdata_dir_config = '--tessdata-dir "C:\\Program Files\\Tesseract-OCR\\tessdata"'
#
# print(pytesseract.image_to_string(img_rgb, lang='chi_sim', config=tessdata_dir_config))
print(pytesseract.image_to_string(img_rgb, lang='chi_sim+eng'))
# print(pytesseract.image_to_string(img_rgb))


# OR
# img_rgb = Image.frombytes('RGB', img_cv.shape[:2], img_cv, 'raw', 'BGR', 0, 0)
# print(pytesseract.image_to_string(img_rgb))



datapath = os.path.join(datafolder,"eurotext.pdf")

from pdf2image import convert_from_path
pages = convert_from_path(datapath, 500)



import PyPDF2

pdfFileObj = open(datapath, 'rb')
pdfReader = PyPDF2.PdfFileReader(pdfFileObj)

print(pdfReader.numPages)

pageObj = pdfReader.getPage(0)
print(pageObj.extractText())

pdfFileObj.close()


from wand.image import Image as Img

img = Img(filename=datapath, resolution=300)
# with Img(filename=datapath, resolution=300) as img:
img.compression_quality = 99
img.save(filename='image_name.jpg')


from PIL import Image


from pdf2image import convert_from_path

images = convert_from_path(datapath)


for index, img in enumerate(images):
    img.save('%s/page_%s.png' % (datafolder, index))


# from pdf2image import convert_from_path
# import tempfile
# def main(filename, outputDir):
#     print('filename=', filename)
#     print('outputDir=', outputDir)
#     with tempfile.TemporaryDirectory() as path:
#         images = convert_from_path(filename)
#         for index, img in enumerate(images):
#             img.save('%s/page_%s.png' % (outputDir, index))
# if __name__ == "__main__":
#     main('source.pdf', 'pdfimage/')