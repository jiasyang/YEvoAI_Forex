from constant import *
from framework.geometry import *
from detection_interface import *
import cv2
import sys
import os
from sklearn.cluster import *


sys.path.append(os.getcwd())

rect = [61,265,2247,1285]
table_pos = {"width": rect[0], "height": rect[1], "width1": rect[2], "height1": rect[3]}
# table_pos = {"width": 187, "height": 243, "width1": 2377, "height1": 1267}
# table_pos = {"width": 91, "height": 293, "width1": 2281, "height1": 1307}

datapath = "data/chinese_invoice"
filename = "invoice_pos.xlsx"
imagefilename = "invoice1_ocr.jpg"

filepath = os.path.join(datapath, filename)
org_table_format = pd.read_excel(open(filepath, 'rb'), sheet_name='Sheet1')
dest_table_format = get_invoicetable(org_table_format,table_pos)

filepath = os.path.join(datapath,imagefilename)
img_full = cv2.imread(filepath)



rect_set = detection_cluster(img_full,dest_table_format)

img_full = draw_rectset_image_cluster(img_full,dest_table_format,rect_set)

imagefilename_dest=imagefilename.split(".")[0]+"_dest.jpg"
filepath = os.path.join(datapath,imagefilename_dest)
cv2.imencode(".jpg",img_full)[1].tofile(filepath)




re_im = cv2.resize(img, (new_w, new_h), interpolation=cv2.INTER_LINEAR)

img_full = cv2.imread(filepath)
rect = [432, 348, 1302, 391]

from cnocr import CnOcr
ocr = CnOcr()
img_sec = img_full[rect[1]:rect[3], rect[0]:rect[2], :]
cv2.imencode(".jpg", img_sec)[1].tofile("test.jpg")

ratio=0.5
new_h = int(img_sec.shape[0]*ratio)
new_w = int(img_sec.shape[1]*ratio)
img = cv2.resize(img_sec, (new_w, new_h), interpolation=cv2.INTER_LINEAR)
res = ocr.ocr(img)
print("".join(i for i in res[0]))

pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'
print(pytesseract.image_to_string(img, lang='eng'))



