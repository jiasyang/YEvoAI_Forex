from constant import *
from framework.geometry import *
from detection_interface import *
import cv2
import sys
import os
from sklearn.cluster import *


sys.path.append(os.getcwd())

rect = [61,265,2247,1285]
table_pos = {"width": rect[0], "height": rect[1], "width1": rect[2], "height1": rect[3]}
# table_pos = {"width": 187, "height": 243, "width1": 2377, "height1": 1267}
# table_pos = {"width": 91, "height": 293, "width1": 2281, "height1": 1307}

datapath = "data/chinese_invoice"
filename = "invoice_pos.xlsx"
filepath = os.path.join(datapath, filename)
org_table_format = pd.read_excel(open(filepath, 'rb'), sheet_name='Sheet1')
dest_table_format = get_invoicetable(org_table_format,table_pos)


imagefilename = "invoice1_ocr.jpg"
filepath = os.path.join(datapath,imagefilename)

img_full = cv2.imread(filepath)


rect_set = detection(checkpoint_path,img_full,dest_table_format)



import numpy as np
def draw_rectset_image(img_full,dest_table_format,rect_set):
    rect_set_keys = list(rect_set.keys())
    for row, items in dest_table_format.iterrows():
        column, width, height, width1, height1, subs = items.to_list()
        img_full = draw_rectonimage(img_full, [width, height, width1, height1])

        if column in rect_set_keys:

            for box in rect_set[column]:
                box = list(np.array(box[:8]) + np.array([width, height]*4))
                cv2.polylines(img_full, [box[:8].astype(np.int32).reshape((-1, 1, 2))], True, color=(0, 255, 0),
                              thickness=1)
    return img_full


img_full = draw_rectset_image(img_full,dest_table_format,rect_set)

imagefilename_dest=imagefilename.split(".")[0]+"_dest.jpg"
filepath = os.path.join(datapath,imagefilename_dest)
cv2.imencode(".jpg",img_full)[1].tofile(filepath)


rect_set = detection_vertical(img_full,dest_table_format)
img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
df_group_cord = compute_split_cords(img_gray)


def draw_rectset_image_cluster(img_full,dest_table_format,rect_set):
    rect_set_keys = list(rect_set.keys())
    for row, items in dest_table_format.iterrows():
        column, width, height, width1, height1, subs = items.to_list()
        img_full = draw_rectonimage(img_full, [width, height, width1, height1])

          if column in rect_set_keys:
            for rect in rect_set[column]

                img_full = draw_rectonimage(img_full, rect)

    return img_full


# print(checkpoint_path)

# import cv2
# datapath = "D:\\Git\\cnn\\dbc_ocr\\data\\demo"
#
# filename = "invoice1_ocr.jpg"
#
# import os
# filepath = os.path.join(datapath,filename)
#
# img = cv2.imread(filepath)
#
# img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
#
# img_vertical = []
# for irow in range(img_gray.shape[0]):
#     img_vertical.append(np.mean(img_gray[irow,:]))
# img_vertical = max(np.array(img_vertical).astype(np.int32))- np.array(img_vertical).astype(np.int32)




import matplotlib.pyplot as plt








