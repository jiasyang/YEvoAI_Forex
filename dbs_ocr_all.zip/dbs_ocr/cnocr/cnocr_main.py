from cnocr import CnOcr
import os
import cv2
ocr = CnOcr()
import pandas as pd
datapath = "D:\\Git\\cnn\\crnn\\cnocr\\page_1"
datapath = "D:\\Git\\cnn\\ocr\\invoice-master\\test"

filepath = os.path.join(datapath,"resize_1.jpg")

img = cv2.imread(filepath)

cordpath = os.path.join(datapath,"resize_1.txt")
cord_data = pd.read_csv(cordpath,header=None)

res_set=[]

import pytesseract
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'

# print(pytesseract.image_to_string(img_rgb, lang='chi_sim+eng'))

for a,row in cord_data.iterrows():
    wid_min = int(row[0])
    wid_max = int(row[2])
    height_min = int(row[1])
    height_max = int(row[5])
    img_sec = img[height_min:height_max,wid_min:wid_max,:]
    cv2.imencode(".jpg",img_sec)[1].tofile("test.jpg")
    res = ocr.ocr(img_sec)
    # print(pytesseract.image_to_string(img_sec, lang='chi_sim+eng'))
    res_set.append(res)
    print("Predicted Chars:", res)