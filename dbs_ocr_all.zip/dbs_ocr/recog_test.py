# -*- coding: utf-8 -*-
from recognition.config import opencvFlag, GPU, IMGSIZE, ocrFlag

import  os
import sys

curpath = os.getcwd()
recog_path = os.path.join(curpath,"recognition")
sys.path.append(recog_path)

if not GPU:
    import os

    os.environ["CUDA_VISIBLE_DEVICES"] = ''

os.environ["CUDA_VISIBLE_DEVICES"] = ''

if ocrFlag == 'torch':
    from recognition.crnn.crnn_torch import crnnOcr as crnnOcr  ##torch版本ocr
elif ocrFlag == 'keras':
    from recognition.crnn.crnn_keras import crnnOcr as crnnOcr  ##keras版本OCR

import time
import cv2
import numpy as np
from PIL import Image
from glob import glob

from recognition.text.detector.detectors import TextDetector
from recognition.apphelper.image import get_boxes, letterbox_image

from recognition.text.opencv_dnn_detect import angle_detect  ##文字方向检测,支持dnn/tensorflow
from recognition.apphelper.image import estimate_skew_angle, rotate_cut_img, xy_rotate_box, sort_box, box_rotate, solve

if opencvFlag == 'opencv':
    from recognition.text import opencv_dnn_detect as detect  ##opencv dnn model for darknet
elif opencvFlag == 'darknet':
    from recognition.text import darknet_detect as detect
else:
    ## keras版本文字检测
    from recognition.text import keras_detectM_invoice as detect

print("Text detect engine:{}".format(opencvFlag))
datapath = "D:\\Git\\dbs_ocr\\data\\chinese_invoice"
filename = "invoice_pos.xlsx"
imagefilename = "invoice3_ocr.jpg"

filepath = os.path.join(datapath,imagefilename)

img_full = cv2.imread(filepath)

from cnocr import CnOcr
ocr = CnOcr()

def ocr_triger(rect,img_full,filepath,offset=8):
    # offset = 5
    img_sec = img_full[rect[1]-offset:rect[3]+offset, rect[0]:rect[2], :]
    cv2.imencode(".jpg", img_sec)[1].tofile(filepath)
    ratio=1
    new_h = int(img_sec.shape[0]*ratio)
    new_w = int(img_sec.shape[1]*ratio)
    img = cv2.resize(img_sec, (new_w, new_h), interpolation=cv2.INTER_LINEAR)
    res = ocr.ocr(img)
    if len(res)>0:
        print("".join(i for i in res[0]))
    im_pil = Image.fromarray(img)
    text = crnnOcr(im_pil.convert('L'))
    # print(text)
    return(text)

# rect = [432, 348, 1302, 391]
# rect = [432, 295, 1302, 334]
# rect = [432, 407, 1302, 445]
# rect = [432, 461, 1302, 509]
# #货物
# rect = [65, 561, 575, 613]
# #规格
# rect = [634, 580, 899, 611]
# # 单位
# rect = [909, 573, 1030, 612]
#
# # 税率': [' \
# rect = [1806, 548, 1914, 631]
#
# # shuliang
# rect = [1040, 580, 1254, 610]
#
# #dang jia
# rect = [1262, 578, 1469, 612]
#
# #jin e
# rect = [1479, 578, 1798, 612]
#
# #税额
# rect = [1920, 574, 2239, 616]
# #'价格税务合计'
# rect = [632, 1000, 2231, 1043]
#
# # '销售方'
# rect = [404, 1080, 1306, 1120]
# rect = [404, 1135, 1306, 1174]
# rect = [404, 1188, 1306, 1221]
# rect = [404, 1239, 1306, 1274]
# # 税率': [' \
# rect = [1806, 548, 1914, 631]

rect_set = {'购买方': [[559, 271, 1430, 310],
  [559, 325, 1430, 367],
  [559, 383, 1430, 421],
  [559, 437, 1430, 475]],
 '密码区': [[1500, 279, 2361, 322],
  [1500, 321, 2361, 365],
  [1500, 364, 2361, 406],
  [1500, 405, 2361, 447]],
 '货物': [[191, 543, 702, 587],
  [191, 589, 702, 630],
  [191, 633, 702, 674],
  [191, 677, 702, 717],
  [191, 720, 702, 761],
  [191, 764, 702, 804],
  [191, 807, 702, 847]],
 '规格型号': [[761, 556, 1026, 584],
  [761, 599, 1026, 628],
  [761, 643, 1026, 671],
  [761, 686, 1026, 715],
  [761, 730, 1026, 758],
  [761, 773, 1026, 801],
  [761, 816, 1026, 845]],
 '单位': [[1036, 545, 1158, 587],
  [1036, 592, 1158, 631],
  [1036, 636, 1158, 674],
  [1036, 680, 1158, 719],
  [1036, 722, 1158, 761],
  [1036, 765, 1158, 803],
  [1036, 808, 1158, 847]],
 '数量': [[1168, 568, 1382, 585],
  [1168, 614, 1382, 629],
  [1168, 659, 1382, 673],
  [1168, 700, 1382, 716],
  [1168, 786, 1382, 801],
  [1168, 816, 1382, 836],
  [1168, 831, 1382, 845]],
 '单价': [[1390, 552, 1598, 586],
  [1390, 596, 1598, 630],
  [1390, 640, 1598, 674],
  [1390, 684, 1598, 717],
  [1390, 728, 1598, 760],
  [1390, 768, 1598, 802],
  [1390, 812, 1598, 846]],
 '金额': [[1608, 552, 1927, 586],
  [1608, 596, 1927, 630],
  [1608, 640, 1927, 673],
  [1608, 683, 1927, 716],
  [1608, 727, 1927, 760],
  [1608, 768, 1927, 801],
  [1608, 812, 1927, 845]],
 '税率': [[1935, 538, 2043, 552],
  [1935, 550, 2043, 585],
  [1935, 596, 2043, 634],
  [1935, 627, 2043, 644],
  [1935, 639, 2043, 676],
  [1935, 679, 2043, 719],
  [1935, 727, 2043, 765],
  [1935, 767, 2043, 801],
  [1935, 811, 2043, 847]],
 '税额': [[2049, 552, 2369, 586],
  [2049, 596, 2369, 629],
  [2049, 639, 2369, 671],
  [2049, 681, 2369, 715],
  [2049, 726, 2369, 759],
  [2049, 767, 2369, 801],
  [2049, 811, 2369, 844]],
 '价格税务合计': [[759, 980, 2361, 1021]],
 '销售方': [[531, 1059, 1434, 1099],
  [531, 1114, 1434, 1155],
  [531, 1167, 1434, 1200],
  [531, 1218, 1434, 1252]]}



rect_set = {'购买方': [[463, 317, 1334, 356],
  [463, 371, 1334, 412],
  [463, 429, 1334, 465],
  [463, 483, 1334, 521]],
 '密码区': [[1404, 324, 2265, 366],
  [1404, 366, 2265, 408],
  [1404, 409, 2265, 450],
  [1404, 450, 2265, 491]],
 '货物': [[95, 592, 606, 630]],
 '规格型号': [],
 '单位': [],
 '数量': [],
 '单价': [],
 '金额': [[1512, 594, 1831, 628]],
 '税率': [[1839, 593, 1947, 627]],
 '税额': [[1953, 592, 2273, 626]],
 '价格税务合计': [[663, 1022, 2265, 1064]],
 '销售方': [[435, 1085, 1338, 1099],
  [435, 1101, 1338, 1140],
  [435, 1155, 1338, 1196],
  [435, 1208, 1338, 1242],
  [435, 1259, 1338, 1292]]}

text_set={}

temp_datapath = os.path.join(datapath,imagefilename.split(".")[0])
if not os.path.exists(temp_datapath):
    os.mkdir(temp_datapath)
for item in list(rect_set.keys()):
    icnt = 0
    text_set[item] = []
    for rect in rect_set[item]:
        filename = "{0}_{1}.jpg".format(item,icnt)
        filepath = os.path.join(temp_datapath,filename)
        text = ocr_triger(rect, img_full, filepath,offset=8)
        text_set[item].append(text)
        icnt = icnt + 1


