import pytesseract
import cv2
import os
from pdf2image import convert_from_path

datafolder = "F:\\MyData\\Photo\\ocr\\test"
datapath = os.path.join(datafolder,"eurotext.pdf")

pages = convert_from_path(datapath, 500)
for index, img in enumerate(images):
    img.save('%s/page_%s.png' % (datafolder, index))