# -*- coding: utf-8 -*-
from recognition.config import opencvFlag, GPU, IMGSIZE, ocrFlag

import  os
import sys

curpath = os.getcwd()
recog_path = os.path.join(curpath,"recognition")
sys.path.append(recog_path)

if not GPU:
    import os

    os.environ["CUDA_VISIBLE_DEVICES"] = ''

os.environ["CUDA_VISIBLE_DEVICES"] = ''

if ocrFlag == 'torch':
    from recognition.crnn.crnn_torch import crnnOcr as crnnOcr  ##torch版本ocr
elif ocrFlag == 'keras':
    from recognition.crnn.crnn_keras import crnnOcr as crnnOcr  ##keras版本OCR

import time
import cv2
import numpy as np
from PIL import Image
from glob import glob

from recognition.text.detector.detectors import TextDetector
from recognition.apphelper.image import get_boxes, letterbox_image

from recognition.text.opencv_dnn_detect import angle_detect  ##文字方向检测,支持dnn/tensorflow
from recognition.apphelper.image import estimate_skew_angle, rotate_cut_img, xy_rotate_box, sort_box, box_rotate, solve

if opencvFlag == 'opencv':
    from recognition.text import opencv_dnn_detect as detect  ##opencv dnn model for darknet
elif opencvFlag == 'darknet':
    from recognition.text import darknet_detect as detect
else:
    from recognition.text import keras_detectM_invoice as detect

def ocr_triger(rect,img_full,filepath,offset=8):
    # offset = 5
    img_sec = img_full[rect[1]-offset:rect[3]+offset, rect[0]:rect[2], :]
    cv2.imencode(".jpg", img_sec)[1].tofile(filepath)
    ratio=1
    new_h = int(img_sec.shape[0]*ratio)
    new_w = int(img_sec.shape[1]*ratio)
    img = cv2.resize(img_sec, (new_w, new_h), interpolation=cv2.INTER_LINEAR)
    # res = ocr.ocr(img)
    # if len(res)>0:
    #     print("".join(i for i in res[0]))
    im_pil = Image.fromarray(img)
    text = crnnOcr(im_pil.convert('L'))
    # print(text)
    return(text)