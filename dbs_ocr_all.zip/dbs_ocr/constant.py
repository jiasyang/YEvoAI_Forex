# tf.app.flags.DEFINE_string('test_data_path', 'data/demo/', '')
# tf.app.flags.DEFINE_string('output_path', 'data/res/', '')
# tf.app.flags.DEFINE_string('gpu', '0', '')
# tf.app.flags.DEFINE_string('checkpoint_path', 'data/model/detection', '')


checkpoint_path = "data/model/detection"