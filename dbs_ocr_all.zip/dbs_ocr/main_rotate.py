

import os
import pandas as pd
import copy
import cv2

# rect = [195,251,2361,457]

rect = 107,277,2283,321
tanx = (rect[3]-rect[1])/(rect[2]-rect[0])
import math
angle = math.atan(tanx)/math.pi*180

datapath = "data\\chinese_invoice"
imagefilename = "invoice3.jpg"
filepath = os.path.join(datapath,imagefilename)
img = cv2.imread(filepath)
# angle=-angle
def rotate_image(img, angle, center=(rect[0],rect[1]), scale=1.0):
    # 获取图像尺寸
    (h, w) = img.shape[:2]

    # 若未指定旋转中心，则将图像中心设为旋转中心
    if center is None:
        center = (w / 2, h / 2)

    # 执行旋转
    M = cv2.getRotationMatrix2D(center, angle, scale)
    rotated = cv2.warpAffine(img, M, (w, h))

    # 返回旋转后的图像
    return rotated

rotated = rotate_image(img,angle)

datapath = "data\\chinese_invoice"
imagefilename_dest = imagefilename.split(".")[0]+"_rot.jpg"
filepath = os.path.join(datapath,imagefilename)
cv2.imencode(".jpg",rotated)[1].tofile(filepath)

datapath = "data\\chinese_invoice"
imagefilename_dest = imagefilename.split(".")[0]+"_ocr.jpg"
filepath = os.path.join(datapath,imagefilename)

cv2.imencode(".jpg",rotated)[1].tofile(filepath)