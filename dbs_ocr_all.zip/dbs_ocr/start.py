from constant import *
from framework.geometry import *
from detection_interface import *
from recognition_interface import *
import cv2
import sys
import os
from sklearn.cluster import *
sys.path.append(os.getcwd())

# rect = [61,265,2247,1285]


datapath = "data/chinese_invoice"
filename = "invoice_pos.xlsx"
imagefilename = "invoice3_ocr.jpg"


task = "chinese_invoice"

if task =="chinese_invoice":

    # step 1: image rotation

    # step 2: find

    # step 3: character detection

    # step 4: character recognition

    # datapath = "data/chinese_invoice"
    #
    # imagefilename = "invoice3_ocr.jpg"

    table_pos = {"width": 61, "height": 61, "width1": 61, "height1": 61}
    table_pos = {"width": 187, "height": 243, "width1": 2377, "height1": 1267}
    table_pos = {"width": 91, "height": 293, "width1": 2281, "height1": 1307}

    # filename = "invoice_pos.xlsx"


    filepath = os.path.join(datapath, filename)

    org_table_format = pd.read_excel(open(filepath, 'rb'), sheet_name='Sheet1')

    dest_table_format = get_invoicetable(org_table_format, table_pos)

    filepath = os.path.join(datapath, imagefilename)

    img_full = cv2.imread(filepath)

    rect_set = detection_cluster(img_full, dest_table_format)

    text_set = {}

    temp_datapath = os.path.join(datapath, imagefilename.split(".")[0])

    if not os.path.exists(temp_datapath):
        os.mkdir(temp_datapath)

    for item in list(rect_set.keys()):
        icnt = 0
        text_set[item] = []
        for rect in rect_set[item]:
            filename = "{0}_{1}.jpg".format(item, icnt)
            filepath = os.path.join(temp_datapath, filename)
            text = ocr_triger(rect, img_full, filepath, offset=8)
            text_set[item].append(text)
            icnt = icnt + 1