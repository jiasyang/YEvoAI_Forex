import os
import pandas as pd
import copy
import cv2


def get_invoicetable(org_table_format,table_pos):
    # filepath = os.path.join(datapath, filename)
    # org_table_format = pd.read_excel(open(filepath, 'rb'), sheet_name='Sheet1')
    dest_table_format = copy.deepcopy(org_table_format)

    max_height = org_table_format[org_table_format["column"] == "table"]["height1"].values[0]
    max_width = org_table_format[org_table_format["column"] == "table"]["width1"].values[0]
    dest_table_format["width"] = org_table_format["width"] / max_width * (table_pos["width1"] - table_pos["width"]) + \
                                 table_pos["width"]
    dest_table_format["height"] = org_table_format["height"] / max_height * (
                table_pos["height1"] - table_pos["height"]) + table_pos["height"]
    dest_table_format["width1"] = org_table_format["width1"] / max_width * (table_pos["width1"] - table_pos["width"]) + \
                                  table_pos["width"]
    dest_table_format["height1"] = org_table_format["height1"] / max_height * (
                table_pos["height1"] - table_pos["height"]) + table_pos["height"]

    dest_table_format[['width', 'height', 'width1', 'height1']] = dest_table_format[
        ['width', 'height', 'width1', 'height1']].astype(int)

    return dest_table_format



def draw_rectonimage(img,rect,color=(255, 0, 0)):
    p1 = (rect[0],rect[1])
    p2 = (rect[2], rect[3])
    cv2.rectangle(img, p1,p2, color, 1)
    return img



# rect = 107,277,2283,321
# tanx = (rect[3]-rect[1])/(rect[2]-rect[0])
# import math
# angle = math.atan(tanx)/math.pi*180
# center=(rect[0],rect[1])
def rotate_image(img, angle, center=None, scale=1.0):
    # 获取图像尺寸
    (h, w) = img.shape[:2]

    # 若未指定旋转中心，则将图像中心设为旋转中心
    if center is None:
        center = (w / 2, h / 2)

    # 执行旋转
    M = cv2.getRotationMatrix2D(center, angle, scale)
    rotated = cv2.warpAffine(img, M, (w, h))

    # 返回旋转后的图像
    return rotated



import numpy as np
def draw_rectset_image(img_full,dest_table_format,rect_set):
    rect_set_keys = list(rect_set.keys())
    for row, items in dest_table_format.iterrows():
        column, width, height, width1, height1, subs = items.to_list()
        img_full = draw_rectonimage(img_full, [width, height, width1, height1])

        if column in rect_set_keys:

            for box in rect_set[column]:
                box = list(np.array(box[:8]) + np.array([width, height]*4))
                cv2.polylines(img_full, [box[:8].astype(np.int32).reshape((-1, 1, 2))], True, color=(0, 255, 0),
                              thickness=1)
    return img_full



def draw_rectset_image_cluster(img_full,dest_table_format,rect_set):
    colorval = (0, 255, 0)
    rect_set_keys = list(rect_set.keys())
    for row, items in dest_table_format.iterrows():
        column, width, height, width1, height1, subs = items.to_list()
        img_full = draw_rectonimage(img_full, [width, height, width1, height1])
        if column in rect_set_keys:
            for rect in rect_set[column]:

                img_full = draw_rectonimage(img_full, rect,colorval)
    return img_full


# def vertical_detection(img):


# def image_lining(img_gray):
#     gray_line = [np.average(line) for line in img_gray]
#     return gray_line
#
# import pandas as pd
# def cluster_line(y_cords,epsnum=35):
#     clustering = DBSCAN(eps=epsnum).fit(y_cords.reshape(-1,1))
#     df_label ={}
#     df_label["cord"] = y_cords
#     df_label["labels"] = clustering.labels_
#     df_label = pd.DataFrame(df_label)
#     return df_label
#
#
# def compute_split_cords(img_gray):
#
#     length_image = img_gray.shape[0]
#     gray_line = image_lining(img_gray)
#     gray_line = [max(gray_line)-i for i in gray_line]
#
#     y_lowbound = 5
#
#     y_cords = [i for i in range(len(gray_line)) if gray_line[i]>y_lowbound]
#
#     y_cords = np.array(y_cords)
#
#     epsnum =4
#
#     df_label = cluster_line(y_cords,epsnum)
#
#     df_label = df_label[df_label["labels"]>=0]
#
#     df_group_cord = df_label.groupby("labels").agg(["min","max"])
#
#     return df_group_cord
