

from recognition.text.opencv_dnn_detect import angle_detect
import numpy as np

import sys
import os
from sklearn.cluster import *
sys.path.append(os.getcwd())


def eval_angle(im, detectAngle=False):
    """
    估计图片偏移角度
    @@param:im
    @@param:detectAngle 是否检测文字朝向
    """
    angle = 0
    img = np.array(im)
    if detectAngle:
        angle = angle_detect(img=np.copy(img))  ##文字朝向检测
        if angle == 90:
            im = Image.fromarray(im).transpose(Image.ROTATE_90)
        elif angle == 180:
            im = Image.fromarray(im).transpose(Image.ROTATE_180)
        elif angle == 270:
            im = Image.fromarray(im).transpose(Image.ROTATE_270)
        img = np.array(im)

    return angle, img


detectAngle=True
import os
datapath = "D:\\Git\\dbs_ocr\\data\\chinese_invoice"
filename ="invoice2.jpg"
filepath = os.path.join(datapath,filename)
import cv2

img = cv2.imread(filepath)

angle, img = eval_angle(img, detectAngle=detectAngle)