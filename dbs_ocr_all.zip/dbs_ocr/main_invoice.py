import os
import pandas as pd
import copy
import cv2
datapath = "data\\chinese_invoice"
filename = "invoice_pos.xlsx"

rect = [61,265,2247,1285]
table_pos = {"width": rect[0], "height": rect[1], "width1": rect[2], "height1": rect[3]}
# table_pos = {"width": 187, "height": 243, "width1": 2377, "height1": 1267}
# table_pos = {"width": 91, "height": 293, "width1": 2281, "height1": 1307}

imagefilename = "invoice1_ocr.jpg"
filepath = os.path.join(datapath,imagefilename)
img = cv2.imread(filepath)

# imagefilename_dest = "invoice3_rect.jpg"
imagefilename_dest = imagefilename.split(".")[0]+"_rect.jpg"

# def get_invoicetable(datapath,filename,table_pos):
def get_invoicetable(org_table_format,table_pos):

    dest_table_format = copy.deepcopy(org_table_format)

    max_height = org_table_format[org_table_format["column"] == "table"]["height1"].values[0]
    max_width = org_table_format[org_table_format["column"] == "table"]["width1"].values[0]
    dest_table_format["width"] = org_table_format["width"] / max_width * (table_pos["width1"] - table_pos["width"]) + \
                                 table_pos["width"]
    dest_table_format["height"] = org_table_format["height"] / max_height * (
                table_pos["height1"] - table_pos["height"]) + table_pos["height"]
    dest_table_format["width1"] = org_table_format["width1"] / max_width * (table_pos["width1"] - table_pos["width"]) + \
                                  table_pos["width"]
    dest_table_format["height1"] = org_table_format["height1"] / max_height * (
                table_pos["height1"] - table_pos["height"]) + table_pos["height"]

    dest_table_format[['width', 'height', 'width1', 'height1']] = dest_table_format[
        ['width', 'height', 'width1', 'height1']].astype(int)

    return dest_table_format



def draw_rectonimage(img,rect):
    p1 = (rect[0],rect[1])
    p2 = (rect[2], rect[3])
    cv2.rectangle(img, p1,p2, (255, 0, 0), 2)
    return img


filepath = os.path.join(datapath, filename)
org_table_format = pd.read_excel(open(filepath, 'rb'), sheet_name='Sheet1')

dest_table_format = get_invoicetable(org_table_format,table_pos)

img_rect = copy.deepcopy(img)
for row,items in dest_table_format.iterrows():
    column,width,height,width1,height1,subs = items.to_list()
    img_rect = draw_rectonimage(img_rect,[width,height,width1,height1])

filepath = os.path.join(datapath,imagefilename_dest)
cv2.imencode(".jpg",img_rect)[1].tofile(filepath)



